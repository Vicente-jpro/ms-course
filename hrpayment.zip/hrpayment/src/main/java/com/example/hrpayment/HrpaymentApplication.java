package com.example.hrpayment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HrpaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrpaymentApplication.class, args);
	}

}
